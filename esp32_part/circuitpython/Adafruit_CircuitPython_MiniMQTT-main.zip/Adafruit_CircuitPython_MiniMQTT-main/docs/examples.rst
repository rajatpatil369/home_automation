Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/minimqtt_simpletest.py
    :caption: examples/minimqtt_simpletest.py
    :linenos:
